-- ==============================================================
-- Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
-- Tool Version Limit: 2025.11
-- Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
-- Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
-- 
-- ==============================================================
library IEEE;
use IEEE.STD_LOGIC_1164.all;
use IEEE.NUMERIC_STD.all;

entity whiteboard_restore_control_s_axi is
generic (
    C_S_AXI_ADDR_WIDTH    : INTEGER := 8;
    C_S_AXI_DATA_WIDTH    : INTEGER := 32);
port (
    ACLK                  :in   STD_LOGIC;
    ARESET                :in   STD_LOGIC;
    ACLK_EN               :in   STD_LOGIC;
    AWADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    AWVALID               :in   STD_LOGIC;
    AWREADY               :out  STD_LOGIC;
    WDATA                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    WSTRB                 :in   STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH/8-1 downto 0);
    WVALID                :in   STD_LOGIC;
    WREADY                :out  STD_LOGIC;
    BRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    BVALID                :out  STD_LOGIC;
    BREADY                :in   STD_LOGIC;
    ARADDR                :in   STD_LOGIC_VECTOR(C_S_AXI_ADDR_WIDTH-1 downto 0);
    ARVALID               :in   STD_LOGIC;
    ARREADY               :out  STD_LOGIC;
    RDATA                 :out  STD_LOGIC_VECTOR(C_S_AXI_DATA_WIDTH-1 downto 0);
    RRESP                 :out  STD_LOGIC_VECTOR(1 downto 0);
    RVALID                :out  STD_LOGIC;
    RREADY                :in   STD_LOGIC;
    interrupt             :out  STD_LOGIC;
    ap_start              :out  STD_LOGIC;
    ap_done               :in   STD_LOGIC;
    ap_ready              :in   STD_LOGIC;
    ap_idle               :in   STD_LOGIC;
    ap_return             :in   STD_LOGIC_VECTOR(31 downto 0);
    input_r               :out  STD_LOGIC_VECTOR(63 downto 0);
    output_r              :out  STD_LOGIC_VECTOR(63 downto 0);
    background            :out  STD_LOGIC_VECTOR(63 downto 0);
    previous              :out  STD_LOGIC_VECTOR(63 downto 0);
    pixel_quiet           :out  STD_LOGIC_VECTOR(63 downto 0);
    block_state           :out  STD_LOGIC_VECTOR(63 downto 0);
    roi                   :out  STD_LOGIC_VECTOR(63 downto 0);
    width                 :out  STD_LOGIC_VECTOR(31 downto 0);
    height                :out  STD_LOGIC_VECTOR(31 downto 0);
    initialize            :out  STD_LOGIC_VECTOR(31 downto 0);
    bgr                   :out  STD_LOGIC_VECTOR(31 downto 0);
    delta                 :out  STD_LOGIC_VECTOR(31 downto 0);
    quiet_delta           :out  STD_LOGIC_VECTOR(31 downto 0);
    dense                 :out  STD_LOGIC_VECTOR(31 downto 0);
    weak_threshold        :out  STD_LOGIC_VECTOR(31 downto 0);
    hold                  :out  STD_LOGIC_VECTOR(31 downto 0);
    stable_r              :out  STD_LOGIC_VECTOR(31 downto 0);
    quiet_max             :out  STD_LOGIC_VECTOR(31 downto 0);
    chalk_min             :out  STD_LOGIC_VECTOR(31 downto 0);
    chalk_spread          :out  STD_LOGIC_VECTOR(31 downto 0);
    fine_min              :out  STD_LOGIC_VECTOR(31 downto 0);
    fine_spread           :out  STD_LOGIC_VECTOR(31 downto 0);
    red_bias              :out  STD_LOGIC_VECTOR(31 downto 0)
);
end entity whiteboard_restore_control_s_axi;

-- ------------------------Address Info-------------------
-- Protocol Used: ap_ctrl_hs
--
-- 0x00 : Control signals
--        bit 0  - ap_start (Read/Write/COH)
--        bit 1  - ap_done (Read/COR)
--        bit 2  - ap_idle (Read)
--        bit 3  - ap_ready (Read/COR)
--        bit 7  - auto_restart (Read/Write)
--        bit 9  - interrupt (Read)
--        others - reserved
-- 0x04 : Global Interrupt Enable Register
--        bit 0  - Global Interrupt Enable (Read/Write)
--        others - reserved
-- 0x08 : IP Interrupt Enable Register (Read/Write)
--        bit 0 - enable ap_done interrupt (Read/Write)
--        bit 1 - enable ap_ready interrupt (Read/Write)
--        others - reserved
-- 0x0c : IP Interrupt Status Register (Read/TOW)
--        bit 0 - ap_done (Read/TOW)
--        bit 1 - ap_ready (Read/TOW)
--        others - reserved
-- 0x10 : Data signal of ap_return
--        bit 31~0 - ap_return[31:0] (Read)
-- 0x18 : Data signal of input_r
--        bit 31~0 - input_r[31:0] (Read/Write)
-- 0x1c : Data signal of input_r
--        bit 31~0 - input_r[63:32] (Read/Write)
-- 0x20 : reserved
-- 0x24 : Data signal of output_r
--        bit 31~0 - output_r[31:0] (Read/Write)
-- 0x28 : Data signal of output_r
--        bit 31~0 - output_r[63:32] (Read/Write)
-- 0x2c : reserved
-- 0x30 : Data signal of background
--        bit 31~0 - background[31:0] (Read/Write)
-- 0x34 : Data signal of background
--        bit 31~0 - background[63:32] (Read/Write)
-- 0x38 : reserved
-- 0x3c : Data signal of previous
--        bit 31~0 - previous[31:0] (Read/Write)
-- 0x40 : Data signal of previous
--        bit 31~0 - previous[63:32] (Read/Write)
-- 0x44 : reserved
-- 0x48 : Data signal of pixel_quiet
--        bit 31~0 - pixel_quiet[31:0] (Read/Write)
-- 0x4c : Data signal of pixel_quiet
--        bit 31~0 - pixel_quiet[63:32] (Read/Write)
-- 0x50 : reserved
-- 0x54 : Data signal of block_state
--        bit 31~0 - block_state[31:0] (Read/Write)
-- 0x58 : Data signal of block_state
--        bit 31~0 - block_state[63:32] (Read/Write)
-- 0x5c : reserved
-- 0x60 : Data signal of roi
--        bit 31~0 - roi[31:0] (Read/Write)
-- 0x64 : Data signal of roi
--        bit 31~0 - roi[63:32] (Read/Write)
-- 0x68 : reserved
-- 0x6c : Data signal of width
--        bit 31~0 - width[31:0] (Read/Write)
-- 0x70 : reserved
-- 0x74 : Data signal of height
--        bit 31~0 - height[31:0] (Read/Write)
-- 0x78 : reserved
-- 0x7c : Data signal of initialize
--        bit 31~0 - initialize[31:0] (Read/Write)
-- 0x80 : reserved
-- 0x84 : Data signal of bgr
--        bit 31~0 - bgr[31:0] (Read/Write)
-- 0x88 : reserved
-- 0x8c : Data signal of delta
--        bit 31~0 - delta[31:0] (Read/Write)
-- 0x90 : reserved
-- 0x94 : Data signal of quiet_delta
--        bit 31~0 - quiet_delta[31:0] (Read/Write)
-- 0x98 : reserved
-- 0x9c : Data signal of dense
--        bit 31~0 - dense[31:0] (Read/Write)
-- 0xa0 : reserved
-- 0xa4 : Data signal of weak_threshold
--        bit 31~0 - weak_threshold[31:0] (Read/Write)
-- 0xa8 : reserved
-- 0xac : Data signal of hold
--        bit 31~0 - hold[31:0] (Read/Write)
-- 0xb0 : reserved
-- 0xb4 : Data signal of stable_r
--        bit 31~0 - stable_r[31:0] (Read/Write)
-- 0xb8 : reserved
-- 0xbc : Data signal of quiet_max
--        bit 31~0 - quiet_max[31:0] (Read/Write)
-- 0xc0 : reserved
-- 0xc4 : Data signal of chalk_min
--        bit 31~0 - chalk_min[31:0] (Read/Write)
-- 0xc8 : reserved
-- 0xcc : Data signal of chalk_spread
--        bit 31~0 - chalk_spread[31:0] (Read/Write)
-- 0xd0 : reserved
-- 0xd4 : Data signal of fine_min
--        bit 31~0 - fine_min[31:0] (Read/Write)
-- 0xd8 : reserved
-- 0xdc : Data signal of fine_spread
--        bit 31~0 - fine_spread[31:0] (Read/Write)
-- 0xe0 : reserved
-- 0xe4 : Data signal of red_bias
--        bit 31~0 - red_bias[31:0] (Read/Write)
-- 0xe8 : reserved
-- (SC = Self Clear, COR = Clear on Read, TOW = Toggle on Write, COH = Clear on Handshake)

architecture behave of whiteboard_restore_control_s_axi is
attribute DowngradeIPIdentifiedWarnings : STRING;
attribute DowngradeIPIdentifiedWarnings of behave : architecture is "yes";
    type states is (wridle, wrdata, wrresp, wrreset, rdidle, rddata, rdreset);  -- read and write fsm states
    signal wstate  : states := wrreset;
    signal rstate  : states := rdreset;
    signal wnext, rnext: states;
    constant ADDR_AP_CTRL               : INTEGER := 16#00#;
    constant ADDR_GIE                   : INTEGER := 16#04#;
    constant ADDR_IER                   : INTEGER := 16#08#;
    constant ADDR_ISR                   : INTEGER := 16#0c#;
    constant ADDR_AP_RETURN_0           : INTEGER := 16#10#;
    constant ADDR_INPUT_R_DATA_0        : INTEGER := 16#18#;
    constant ADDR_INPUT_R_DATA_1        : INTEGER := 16#1c#;
    constant ADDR_INPUT_R_CTRL          : INTEGER := 16#20#;
    constant ADDR_OUTPUT_R_DATA_0       : INTEGER := 16#24#;
    constant ADDR_OUTPUT_R_DATA_1       : INTEGER := 16#28#;
    constant ADDR_OUTPUT_R_CTRL         : INTEGER := 16#2c#;
    constant ADDR_BACKGROUND_DATA_0     : INTEGER := 16#30#;
    constant ADDR_BACKGROUND_DATA_1     : INTEGER := 16#34#;
    constant ADDR_BACKGROUND_CTRL       : INTEGER := 16#38#;
    constant ADDR_PREVIOUS_DATA_0       : INTEGER := 16#3c#;
    constant ADDR_PREVIOUS_DATA_1       : INTEGER := 16#40#;
    constant ADDR_PREVIOUS_CTRL         : INTEGER := 16#44#;
    constant ADDR_PIXEL_QUIET_DATA_0    : INTEGER := 16#48#;
    constant ADDR_PIXEL_QUIET_DATA_1    : INTEGER := 16#4c#;
    constant ADDR_PIXEL_QUIET_CTRL      : INTEGER := 16#50#;
    constant ADDR_BLOCK_STATE_DATA_0    : INTEGER := 16#54#;
    constant ADDR_BLOCK_STATE_DATA_1    : INTEGER := 16#58#;
    constant ADDR_BLOCK_STATE_CTRL      : INTEGER := 16#5c#;
    constant ADDR_ROI_DATA_0            : INTEGER := 16#60#;
    constant ADDR_ROI_DATA_1            : INTEGER := 16#64#;
    constant ADDR_ROI_CTRL              : INTEGER := 16#68#;
    constant ADDR_WIDTH_DATA_0          : INTEGER := 16#6c#;
    constant ADDR_WIDTH_CTRL            : INTEGER := 16#70#;
    constant ADDR_HEIGHT_DATA_0         : INTEGER := 16#74#;
    constant ADDR_HEIGHT_CTRL           : INTEGER := 16#78#;
    constant ADDR_INITIALIZE_DATA_0     : INTEGER := 16#7c#;
    constant ADDR_INITIALIZE_CTRL       : INTEGER := 16#80#;
    constant ADDR_BGR_DATA_0            : INTEGER := 16#84#;
    constant ADDR_BGR_CTRL              : INTEGER := 16#88#;
    constant ADDR_DELTA_DATA_0          : INTEGER := 16#8c#;
    constant ADDR_DELTA_CTRL            : INTEGER := 16#90#;
    constant ADDR_QUIET_DELTA_DATA_0    : INTEGER := 16#94#;
    constant ADDR_QUIET_DELTA_CTRL      : INTEGER := 16#98#;
    constant ADDR_DENSE_DATA_0          : INTEGER := 16#9c#;
    constant ADDR_DENSE_CTRL            : INTEGER := 16#a0#;
    constant ADDR_WEAK_THRESHOLD_DATA_0 : INTEGER := 16#a4#;
    constant ADDR_WEAK_THRESHOLD_CTRL   : INTEGER := 16#a8#;
    constant ADDR_HOLD_DATA_0           : INTEGER := 16#ac#;
    constant ADDR_HOLD_CTRL             : INTEGER := 16#b0#;
    constant ADDR_STABLE_R_DATA_0       : INTEGER := 16#b4#;
    constant ADDR_STABLE_R_CTRL         : INTEGER := 16#b8#;
    constant ADDR_QUIET_MAX_DATA_0      : INTEGER := 16#bc#;
    constant ADDR_QUIET_MAX_CTRL        : INTEGER := 16#c0#;
    constant ADDR_CHALK_MIN_DATA_0      : INTEGER := 16#c4#;
    constant ADDR_CHALK_MIN_CTRL        : INTEGER := 16#c8#;
    constant ADDR_CHALK_SPREAD_DATA_0   : INTEGER := 16#cc#;
    constant ADDR_CHALK_SPREAD_CTRL     : INTEGER := 16#d0#;
    constant ADDR_FINE_MIN_DATA_0       : INTEGER := 16#d4#;
    constant ADDR_FINE_MIN_CTRL         : INTEGER := 16#d8#;
    constant ADDR_FINE_SPREAD_DATA_0    : INTEGER := 16#dc#;
    constant ADDR_FINE_SPREAD_CTRL      : INTEGER := 16#e0#;
    constant ADDR_RED_BIAS_DATA_0       : INTEGER := 16#e4#;
    constant ADDR_RED_BIAS_CTRL         : INTEGER := 16#e8#;
    constant ADDR_BITS         : INTEGER := 8;

    signal AWREADY_t           : STD_LOGIC;
    signal WREADY_t            : STD_LOGIC;
    signal ARREADY_t           : STD_LOGIC;
    signal RVALID_t            : STD_LOGIC;
    signal BVALID_t            : STD_LOGIC;
    signal waddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    signal wmask               : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal aw_hs               : STD_LOGIC;
    signal w_hs                : STD_LOGIC;
    signal rdata_data          : UNSIGNED(C_S_AXI_DATA_WIDTH-1 downto 0);
    signal ar_hs               : STD_LOGIC;
    signal raddr               : UNSIGNED(ADDR_BITS-1 downto 0);
    -- internal registers
    signal int_ap_idle         : STD_LOGIC := '0';
    signal int_ap_ready        : STD_LOGIC := '0';
    signal task_ap_ready       : STD_LOGIC;
    signal int_ap_done         : STD_LOGIC := '0';
    signal task_ap_done        : STD_LOGIC;
    signal int_task_ap_done    : STD_LOGIC := '0';
    signal int_ap_start        : STD_LOGIC := '0';
    signal int_interrupt       : STD_LOGIC := '0';
    signal int_auto_restart    : STD_LOGIC := '0';
    signal auto_restart_status : STD_LOGIC := '0';
    signal auto_restart_done   : STD_LOGIC;
    signal int_gie             : STD_LOGIC := '0';
    signal int_ier             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_isr             : UNSIGNED(1 downto 0) := (others => '0');
    signal int_ap_return       : UNSIGNED(31 downto 0);
    signal int_input_r         : UNSIGNED(63 downto 0) := (others => '0');
    signal int_output_r        : UNSIGNED(63 downto 0) := (others => '0');
    signal int_background      : UNSIGNED(63 downto 0) := (others => '0');
    signal int_previous        : UNSIGNED(63 downto 0) := (others => '0');
    signal int_pixel_quiet     : UNSIGNED(63 downto 0) := (others => '0');
    signal int_block_state     : UNSIGNED(63 downto 0) := (others => '0');
    signal int_roi             : UNSIGNED(63 downto 0) := (others => '0');
    signal int_width           : UNSIGNED(31 downto 0) := (others => '0');
    signal int_height          : UNSIGNED(31 downto 0) := (others => '0');
    signal int_initialize      : UNSIGNED(31 downto 0) := (others => '0');
    signal int_bgr             : UNSIGNED(31 downto 0) := (others => '0');
    signal int_delta           : UNSIGNED(31 downto 0) := (others => '0');
    signal int_quiet_delta     : UNSIGNED(31 downto 0) := (others => '0');
    signal int_dense           : UNSIGNED(31 downto 0) := (others => '0');
    signal int_weak_threshold  : UNSIGNED(31 downto 0) := (others => '0');
    signal int_hold            : UNSIGNED(31 downto 0) := (others => '0');
    signal int_stable_r        : UNSIGNED(31 downto 0) := (others => '0');
    signal int_quiet_max       : UNSIGNED(31 downto 0) := (others => '0');
    signal int_chalk_min       : UNSIGNED(31 downto 0) := (others => '0');
    signal int_chalk_spread    : UNSIGNED(31 downto 0) := (others => '0');
    signal int_fine_min        : UNSIGNED(31 downto 0) := (others => '0');
    signal int_fine_spread     : UNSIGNED(31 downto 0) := (others => '0');
    signal int_red_bias        : UNSIGNED(31 downto 0) := (others => '0');


begin
-- ----------------------- Instantiation------------------


-- ----------------------- AXI WRITE ---------------------
    AWREADY_t <=  '1' when wstate = wridle else '0';
    AWREADY   <=  AWREADY_t;
    WREADY_t  <=  '1' when wstate = wrdata else '0';
    WREADY    <=  WREADY_t;
    BVALID_t  <=  '1' when wstate = wrresp else '0';
    BVALID    <=  BVALID_t;
    BRESP     <=  "00";  -- OKAY
    wmask     <=  (31 downto 24 => WSTRB(3), 23 downto 16 => WSTRB(2), 15 downto 8 => WSTRB(1), 7 downto 0 => WSTRB(0));
    aw_hs     <=  AWVALID and AWREADY_t;
    w_hs      <=  WVALID and WREADY_t;

    -- write FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                wstate <= wrreset;
            elsif (ACLK_EN = '1') then
                wstate <= wnext;
            end if;
        end if;
    end process;

    process (wstate, AWVALID, WVALID, BREADY, BVALID_t)
    begin
        case (wstate) is
        when wridle =>
            if (AWVALID = '1') then
                wnext <= wrdata;
            else
                wnext <= wridle;
            end if;
        when wrdata =>
            if (WVALID = '1') then
                wnext <= wrresp;
            else
                wnext <= wrdata;
            end if;
        when wrresp =>
            if (BREADY = '1' and BVALID_t = '1') then
                wnext <= wridle;
            else
                wnext <= wrresp;
            end if;
        when others =>
            wnext <= wridle;
        end case;
    end process;

    waddr_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (aw_hs = '1') then
                    waddr <= UNSIGNED(AWADDR(ADDR_BITS-1 downto 2) & (1 downto 0 => '0'));
                end if;
            end if;
        end if;
    end process;

-- ----------------------- AXI READ ----------------------
    ARREADY_t <= '1' when (rstate = rdidle) else '0';
    ARREADY <= ARREADY_t;
    RDATA   <= STD_LOGIC_VECTOR(rdata_data);
    RRESP   <= "00";  -- OKAY
    RVALID_t  <= '1' when (rstate = rddata) else '0';
    RVALID    <= RVALID_t;
    ar_hs   <= ARVALID and ARREADY_t;
    raddr   <= UNSIGNED(ARADDR(ADDR_BITS-1 downto 0));

    -- read FSM
    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                rstate <= rdreset;
            elsif (ACLK_EN = '1') then
                rstate <= rnext;
            end if;
        end if;
    end process;

    process (rstate, ARVALID, RREADY, RVALID_t)
    begin
        case (rstate) is
        when rdidle =>
            if (ARVALID = '1') then
                rnext <= rddata;
            else
                rnext <= rdidle;
            end if;
        when rddata =>
            if (RREADY = '1' and RVALID_t = '1') then
                rnext <= rdidle;
            else
                rnext <= rddata;
            end if;
        when others =>
            rnext <= rdidle;
        end case;
    end process;

    rdata_proc : process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ACLK_EN = '1') then
                if (ar_hs = '1') then
                    rdata_data <= (others => '0');
                    case (TO_INTEGER(raddr)) is
                    when ADDR_AP_CTRL =>
                        rdata_data(9) <= int_interrupt;
                        rdata_data(7) <= int_auto_restart;
                        rdata_data(3) <= int_ap_ready;
                        rdata_data(2) <= int_ap_idle;
                        rdata_data(1) <= int_task_ap_done;
                        rdata_data(0) <= int_ap_start;
                    when ADDR_GIE =>
                        rdata_data(0) <= int_gie;
                    when ADDR_IER =>
                        rdata_data(1 downto 0) <= int_ier;
                    when ADDR_ISR =>
                        rdata_data(1 downto 0) <= int_isr;
                    when ADDR_AP_RETURN_0 =>
                        rdata_data <= RESIZE(int_ap_return(31 downto 0), 32);
                    when ADDR_INPUT_R_DATA_0 =>
                        rdata_data <= RESIZE(int_input_r(31 downto 0), 32);
                    when ADDR_INPUT_R_DATA_1 =>
                        rdata_data <= RESIZE(int_input_r(63 downto 32), 32);
                    when ADDR_OUTPUT_R_DATA_0 =>
                        rdata_data <= RESIZE(int_output_r(31 downto 0), 32);
                    when ADDR_OUTPUT_R_DATA_1 =>
                        rdata_data <= RESIZE(int_output_r(63 downto 32), 32);
                    when ADDR_BACKGROUND_DATA_0 =>
                        rdata_data <= RESIZE(int_background(31 downto 0), 32);
                    when ADDR_BACKGROUND_DATA_1 =>
                        rdata_data <= RESIZE(int_background(63 downto 32), 32);
                    when ADDR_PREVIOUS_DATA_0 =>
                        rdata_data <= RESIZE(int_previous(31 downto 0), 32);
                    when ADDR_PREVIOUS_DATA_1 =>
                        rdata_data <= RESIZE(int_previous(63 downto 32), 32);
                    when ADDR_PIXEL_QUIET_DATA_0 =>
                        rdata_data <= RESIZE(int_pixel_quiet(31 downto 0), 32);
                    when ADDR_PIXEL_QUIET_DATA_1 =>
                        rdata_data <= RESIZE(int_pixel_quiet(63 downto 32), 32);
                    when ADDR_BLOCK_STATE_DATA_0 =>
                        rdata_data <= RESIZE(int_block_state(31 downto 0), 32);
                    when ADDR_BLOCK_STATE_DATA_1 =>
                        rdata_data <= RESIZE(int_block_state(63 downto 32), 32);
                    when ADDR_ROI_DATA_0 =>
                        rdata_data <= RESIZE(int_roi(31 downto 0), 32);
                    when ADDR_ROI_DATA_1 =>
                        rdata_data <= RESIZE(int_roi(63 downto 32), 32);
                    when ADDR_WIDTH_DATA_0 =>
                        rdata_data <= RESIZE(int_width(31 downto 0), 32);
                    when ADDR_HEIGHT_DATA_0 =>
                        rdata_data <= RESIZE(int_height(31 downto 0), 32);
                    when ADDR_INITIALIZE_DATA_0 =>
                        rdata_data <= RESIZE(int_initialize(31 downto 0), 32);
                    when ADDR_BGR_DATA_0 =>
                        rdata_data <= RESIZE(int_bgr(31 downto 0), 32);
                    when ADDR_DELTA_DATA_0 =>
                        rdata_data <= RESIZE(int_delta(31 downto 0), 32);
                    when ADDR_QUIET_DELTA_DATA_0 =>
                        rdata_data <= RESIZE(int_quiet_delta(31 downto 0), 32);
                    when ADDR_DENSE_DATA_0 =>
                        rdata_data <= RESIZE(int_dense(31 downto 0), 32);
                    when ADDR_WEAK_THRESHOLD_DATA_0 =>
                        rdata_data <= RESIZE(int_weak_threshold(31 downto 0), 32);
                    when ADDR_HOLD_DATA_0 =>
                        rdata_data <= RESIZE(int_hold(31 downto 0), 32);
                    when ADDR_STABLE_R_DATA_0 =>
                        rdata_data <= RESIZE(int_stable_r(31 downto 0), 32);
                    when ADDR_QUIET_MAX_DATA_0 =>
                        rdata_data <= RESIZE(int_quiet_max(31 downto 0), 32);
                    when ADDR_CHALK_MIN_DATA_0 =>
                        rdata_data <= RESIZE(int_chalk_min(31 downto 0), 32);
                    when ADDR_CHALK_SPREAD_DATA_0 =>
                        rdata_data <= RESIZE(int_chalk_spread(31 downto 0), 32);
                    when ADDR_FINE_MIN_DATA_0 =>
                        rdata_data <= RESIZE(int_fine_min(31 downto 0), 32);
                    when ADDR_FINE_SPREAD_DATA_0 =>
                        rdata_data <= RESIZE(int_fine_spread(31 downto 0), 32);
                    when ADDR_RED_BIAS_DATA_0 =>
                        rdata_data <= RESIZE(int_red_bias(31 downto 0), 32);
                    when others =>
                        NULL;
                    end case;
                end if;
            end if;
        end if;
    end process;

-- ----------------------- Register logic ----------------
    interrupt            <= int_interrupt;
    ap_start             <= int_ap_start;
    task_ap_done         <= (ap_done and not auto_restart_status) or auto_restart_done;
    task_ap_ready        <= ap_ready and not int_auto_restart;
    auto_restart_done    <= auto_restart_status and (ap_idle and not int_ap_idle);
    input_r              <= STD_LOGIC_VECTOR(int_input_r);
    output_r             <= STD_LOGIC_VECTOR(int_output_r);
    background           <= STD_LOGIC_VECTOR(int_background);
    previous             <= STD_LOGIC_VECTOR(int_previous);
    pixel_quiet          <= STD_LOGIC_VECTOR(int_pixel_quiet);
    block_state          <= STD_LOGIC_VECTOR(int_block_state);
    roi                  <= STD_LOGIC_VECTOR(int_roi);
    width                <= STD_LOGIC_VECTOR(int_width);
    height               <= STD_LOGIC_VECTOR(int_height);
    initialize           <= STD_LOGIC_VECTOR(int_initialize);
    bgr                  <= STD_LOGIC_VECTOR(int_bgr);
    delta                <= STD_LOGIC_VECTOR(int_delta);
    quiet_delta          <= STD_LOGIC_VECTOR(int_quiet_delta);
    dense                <= STD_LOGIC_VECTOR(int_dense);
    weak_threshold       <= STD_LOGIC_VECTOR(int_weak_threshold);
    hold                 <= STD_LOGIC_VECTOR(int_hold);
    stable_r             <= STD_LOGIC_VECTOR(int_stable_r);
    quiet_max            <= STD_LOGIC_VECTOR(int_quiet_max);
    chalk_min            <= STD_LOGIC_VECTOR(int_chalk_min);
    chalk_spread         <= STD_LOGIC_VECTOR(int_chalk_spread);
    fine_min             <= STD_LOGIC_VECTOR(int_fine_min);
    fine_spread          <= STD_LOGIC_VECTOR(int_fine_spread);
    red_bias             <= STD_LOGIC_VECTOR(int_red_bias);

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_interrupt <= '0';
            elsif (ACLK_EN = '1') then
                if (int_gie = '1' and (int_isr(0) or int_isr(1)) = '1') then
                    int_interrupt <= '1';
                else
                    int_interrupt <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_start <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1' and WDATA(0) = '1') then
                    int_ap_start <= '1';
                elsif (ap_ready = '1') then
                    int_ap_start <= int_auto_restart; -- clear on handshake/auto restart
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_done <= ap_done;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_task_ap_done <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_done = '1') then
                    int_task_ap_done <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_task_ap_done <= '0'; -- clear on read
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_idle <= '0';
            elsif (ACLK_EN = '1') then
                if (true) then
                    int_ap_idle <= ap_idle;
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_ready <= '0';
            elsif (ACLK_EN = '1') then
                if (task_ap_ready = '1') then
                    int_ap_ready <= '1';
                elsif (ar_hs = '1' and raddr = ADDR_AP_CTRL) then
                    int_ap_ready <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_auto_restart <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_AP_CTRL and WSTRB(0) = '1') then
                    int_auto_restart <= WDATA(7);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                auto_restart_status <= '0';
            elsif (ACLK_EN = '1') then
                if (int_auto_restart = '1') then
                    auto_restart_status <= '1';
                elsif (ap_idle = '1') then
                    auto_restart_status <= '0';
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_gie <= '0';
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_GIE and WSTRB(0) = '1') then
                    int_gie <= WDATA(0);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ier <= (others=>'0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_IER and WSTRB(0) = '1') then
                    int_ier <= UNSIGNED(WDATA(1 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(0) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(0) = '1' and ap_done = '1') then
                    int_isr(0) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(0) <= int_isr(0) xor WDATA(0); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_isr(1) <= '0';
            elsif (ACLK_EN = '1') then
                if (int_ier(1) = '1' and ap_ready = '1') then
                    int_isr(1) <= '1';
                elsif (w_hs = '1' and waddr = ADDR_ISR and WSTRB(0) = '1') then
                    int_isr(1) <= int_isr(1) xor WDATA(1); -- toggle on write
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_ap_return <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (ap_done = '1') then
                    int_ap_return <= UNSIGNED(ap_return);
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_input_r(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_INPUT_R_DATA_0) then
                    int_input_r(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_input_r(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_input_r(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_INPUT_R_DATA_1) then
                    int_input_r(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_input_r(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_output_r(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_OUTPUT_R_DATA_0) then
                    int_output_r(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_output_r(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_output_r(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_OUTPUT_R_DATA_1) then
                    int_output_r(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_output_r(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_background(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BACKGROUND_DATA_0) then
                    int_background(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_background(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_background(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BACKGROUND_DATA_1) then
                    int_background(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_background(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_previous(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PREVIOUS_DATA_0) then
                    int_previous(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_previous(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_previous(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PREVIOUS_DATA_1) then
                    int_previous(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_previous(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_pixel_quiet(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PIXEL_QUIET_DATA_0) then
                    int_pixel_quiet(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_pixel_quiet(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_pixel_quiet(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_PIXEL_QUIET_DATA_1) then
                    int_pixel_quiet(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_pixel_quiet(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_block_state(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BLOCK_STATE_DATA_0) then
                    int_block_state(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_block_state(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_block_state(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BLOCK_STATE_DATA_1) then
                    int_block_state(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_block_state(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_roi(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_ROI_DATA_0) then
                    int_roi(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_roi(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_roi(63 downto 32) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_ROI_DATA_1) then
                    int_roi(63 downto 32) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_roi(63 downto 32));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_width(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_WIDTH_DATA_0) then
                    int_width(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_width(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_height(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_HEIGHT_DATA_0) then
                    int_height(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_height(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_initialize(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_INITIALIZE_DATA_0) then
                    int_initialize(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_initialize(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_bgr(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_BGR_DATA_0) then
                    int_bgr(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_bgr(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_delta(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_DELTA_DATA_0) then
                    int_delta(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_delta(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_quiet_delta(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_QUIET_DELTA_DATA_0) then
                    int_quiet_delta(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_quiet_delta(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_dense(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_DENSE_DATA_0) then
                    int_dense(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_dense(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_weak_threshold(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_WEAK_THRESHOLD_DATA_0) then
                    int_weak_threshold(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_weak_threshold(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_hold(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_HOLD_DATA_0) then
                    int_hold(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_hold(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_stable_r(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_STABLE_R_DATA_0) then
                    int_stable_r(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_stable_r(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_quiet_max(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_QUIET_MAX_DATA_0) then
                    int_quiet_max(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_quiet_max(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_chalk_min(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_CHALK_MIN_DATA_0) then
                    int_chalk_min(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_chalk_min(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_chalk_spread(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_CHALK_SPREAD_DATA_0) then
                    int_chalk_spread(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_chalk_spread(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_fine_min(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_FINE_MIN_DATA_0) then
                    int_fine_min(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_fine_min(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_fine_spread(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_FINE_SPREAD_DATA_0) then
                    int_fine_spread(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_fine_spread(31 downto 0));
                end if;
            end if;
        end if;
    end process;

    process (ACLK)
    begin
        if (ACLK'event and ACLK = '1') then
            if (ARESET = '1') then
                int_red_bias(31 downto 0) <= (others => '0');
            elsif (ACLK_EN = '1') then
                if (w_hs = '1' and waddr = ADDR_RED_BIAS_DATA_0) then
                    int_red_bias(31 downto 0) <= (UNSIGNED(WDATA(31 downto 0)) and wmask(31 downto 0)) or ((not wmask(31 downto 0)) and int_red_bias(31 downto 0));
                end if;
            end if;
        end if;
    end process;


-- ----------------------- Memory logic ------------------

end architecture behave;
