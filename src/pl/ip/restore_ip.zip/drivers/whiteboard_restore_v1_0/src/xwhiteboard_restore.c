// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xwhiteboard_restore.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XWhiteboard_restore_CfgInitialize(XWhiteboard_restore *InstancePtr, XWhiteboard_restore_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XWhiteboard_restore_Start(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XWhiteboard_restore_IsDone(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XWhiteboard_restore_IsIdle(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XWhiteboard_restore_IsReady(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XWhiteboard_restore_EnableAutoRestart(XWhiteboard_restore *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XWhiteboard_restore_DisableAutoRestart(XWhiteboard_restore *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XWhiteboard_restore_Get_return(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XWhiteboard_restore_Set_input_r(XWhiteboard_restore *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_INPUT_R_DATA, (u32)(Data));
    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_INPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XWhiteboard_restore_Get_input_r(XWhiteboard_restore *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_INPUT_R_DATA);
    Data += (u64)XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_INPUT_R_DATA + 4) << 32;
    return Data;
}

void XWhiteboard_restore_Set_output_r(XWhiteboard_restore *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_OUTPUT_R_DATA, (u32)(Data));
    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_OUTPUT_R_DATA + 4, (u32)(Data >> 32));
}

u64 XWhiteboard_restore_Get_output_r(XWhiteboard_restore *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_OUTPUT_R_DATA);
    Data += (u64)XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_OUTPUT_R_DATA + 4) << 32;
    return Data;
}

void XWhiteboard_restore_Set_background(XWhiteboard_restore *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_BACKGROUND_DATA, (u32)(Data));
    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_BACKGROUND_DATA + 4, (u32)(Data >> 32));
}

u64 XWhiteboard_restore_Get_background(XWhiteboard_restore *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_BACKGROUND_DATA);
    Data += (u64)XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_BACKGROUND_DATA + 4) << 32;
    return Data;
}

void XWhiteboard_restore_Set_previous(XWhiteboard_restore *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_PREVIOUS_DATA, (u32)(Data));
    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_PREVIOUS_DATA + 4, (u32)(Data >> 32));
}

u64 XWhiteboard_restore_Get_previous(XWhiteboard_restore *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_PREVIOUS_DATA);
    Data += (u64)XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_PREVIOUS_DATA + 4) << 32;
    return Data;
}

void XWhiteboard_restore_Set_pixel_quiet(XWhiteboard_restore *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_PIXEL_QUIET_DATA, (u32)(Data));
    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_PIXEL_QUIET_DATA + 4, (u32)(Data >> 32));
}

u64 XWhiteboard_restore_Get_pixel_quiet(XWhiteboard_restore *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_PIXEL_QUIET_DATA);
    Data += (u64)XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_PIXEL_QUIET_DATA + 4) << 32;
    return Data;
}

void XWhiteboard_restore_Set_block_state(XWhiteboard_restore *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_BLOCK_STATE_DATA, (u32)(Data));
    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_BLOCK_STATE_DATA + 4, (u32)(Data >> 32));
}

u64 XWhiteboard_restore_Get_block_state(XWhiteboard_restore *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_BLOCK_STATE_DATA);
    Data += (u64)XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_BLOCK_STATE_DATA + 4) << 32;
    return Data;
}

void XWhiteboard_restore_Set_roi(XWhiteboard_restore *InstancePtr, u64 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_ROI_DATA, (u32)(Data));
    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_ROI_DATA + 4, (u32)(Data >> 32));
}

u64 XWhiteboard_restore_Get_roi(XWhiteboard_restore *InstancePtr) {
    u64 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_ROI_DATA);
    Data += (u64)XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_ROI_DATA + 4) << 32;
    return Data;
}

void XWhiteboard_restore_Set_width(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XWhiteboard_restore_Get_width(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XWhiteboard_restore_Set_height(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XWhiteboard_restore_Get_height(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XWhiteboard_restore_Set_initialize(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_INITIALIZE_DATA, Data);
}

u32 XWhiteboard_restore_Get_initialize(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_INITIALIZE_DATA);
    return Data;
}

void XWhiteboard_restore_Set_bgr(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_BGR_DATA, Data);
}

u32 XWhiteboard_restore_Get_bgr(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_BGR_DATA);
    return Data;
}

void XWhiteboard_restore_Set_delta(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_DELTA_DATA, Data);
}

u32 XWhiteboard_restore_Get_delta(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_DELTA_DATA);
    return Data;
}

void XWhiteboard_restore_Set_quiet_delta(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_QUIET_DELTA_DATA, Data);
}

u32 XWhiteboard_restore_Get_quiet_delta(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_QUIET_DELTA_DATA);
    return Data;
}

void XWhiteboard_restore_Set_dense(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_DENSE_DATA, Data);
}

u32 XWhiteboard_restore_Get_dense(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_DENSE_DATA);
    return Data;
}

void XWhiteboard_restore_Set_weak_threshold(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_WEAK_THRESHOLD_DATA, Data);
}

u32 XWhiteboard_restore_Get_weak_threshold(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_WEAK_THRESHOLD_DATA);
    return Data;
}

void XWhiteboard_restore_Set_hold(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_HOLD_DATA, Data);
}

u32 XWhiteboard_restore_Get_hold(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_HOLD_DATA);
    return Data;
}

void XWhiteboard_restore_Set_stable_r(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_STABLE_R_DATA, Data);
}

u32 XWhiteboard_restore_Get_stable_r(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_STABLE_R_DATA);
    return Data;
}

void XWhiteboard_restore_Set_quiet_max(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_QUIET_MAX_DATA, Data);
}

u32 XWhiteboard_restore_Get_quiet_max(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_QUIET_MAX_DATA);
    return Data;
}

void XWhiteboard_restore_Set_chalk_min(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_CHALK_MIN_DATA, Data);
}

u32 XWhiteboard_restore_Get_chalk_min(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_CHALK_MIN_DATA);
    return Data;
}

void XWhiteboard_restore_Set_chalk_spread(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_CHALK_SPREAD_DATA, Data);
}

u32 XWhiteboard_restore_Get_chalk_spread(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_CHALK_SPREAD_DATA);
    return Data;
}

void XWhiteboard_restore_Set_fine_min(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_FINE_MIN_DATA, Data);
}

u32 XWhiteboard_restore_Get_fine_min(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_FINE_MIN_DATA);
    return Data;
}

void XWhiteboard_restore_Set_fine_spread(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_FINE_SPREAD_DATA, Data);
}

u32 XWhiteboard_restore_Get_fine_spread(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_FINE_SPREAD_DATA);
    return Data;
}

void XWhiteboard_restore_Set_red_bias(XWhiteboard_restore *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_RED_BIAS_DATA, Data);
}

u32 XWhiteboard_restore_Get_red_bias(XWhiteboard_restore *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_RED_BIAS_DATA);
    return Data;
}

void XWhiteboard_restore_InterruptGlobalEnable(XWhiteboard_restore *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_GIE, 1);
}

void XWhiteboard_restore_InterruptGlobalDisable(XWhiteboard_restore *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_GIE, 0);
}

void XWhiteboard_restore_InterruptEnable(XWhiteboard_restore *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_IER);
    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_IER, Register | Mask);
}

void XWhiteboard_restore_InterruptDisable(XWhiteboard_restore *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_IER);
    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XWhiteboard_restore_InterruptClear(XWhiteboard_restore *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XWhiteboard_restore_WriteReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_ISR, Mask);
}

u32 XWhiteboard_restore_InterruptGetEnabled(XWhiteboard_restore *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_IER);
}

u32 XWhiteboard_restore_InterruptGetStatus(XWhiteboard_restore *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XWhiteboard_restore_ReadReg(InstancePtr->Control_BaseAddress, XWHITEBOARD_RESTORE_CONTROL_ADDR_ISR);
}

