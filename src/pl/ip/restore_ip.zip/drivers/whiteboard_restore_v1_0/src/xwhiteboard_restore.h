// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XWHITEBOARD_RESTORE_H
#define XWHITEBOARD_RESTORE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xwhiteboard_restore_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u64 Control_BaseAddress;
} XWhiteboard_restore_Config;
#endif

typedef struct {
    u64 Control_BaseAddress;
    u32 IsReady;
} XWhiteboard_restore;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XWhiteboard_restore_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XWhiteboard_restore_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XWhiteboard_restore_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XWhiteboard_restore_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XWhiteboard_restore_Initialize(XWhiteboard_restore *InstancePtr, UINTPTR BaseAddress);
XWhiteboard_restore_Config* XWhiteboard_restore_LookupConfig(UINTPTR BaseAddress);
#else
int XWhiteboard_restore_Initialize(XWhiteboard_restore *InstancePtr, u16 DeviceId);
XWhiteboard_restore_Config* XWhiteboard_restore_LookupConfig(u16 DeviceId);
#endif
int XWhiteboard_restore_CfgInitialize(XWhiteboard_restore *InstancePtr, XWhiteboard_restore_Config *ConfigPtr);
#else
int XWhiteboard_restore_Initialize(XWhiteboard_restore *InstancePtr, const char* InstanceName);
int XWhiteboard_restore_Release(XWhiteboard_restore *InstancePtr);
#endif

void XWhiteboard_restore_Start(XWhiteboard_restore *InstancePtr);
u32 XWhiteboard_restore_IsDone(XWhiteboard_restore *InstancePtr);
u32 XWhiteboard_restore_IsIdle(XWhiteboard_restore *InstancePtr);
u32 XWhiteboard_restore_IsReady(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_EnableAutoRestart(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_DisableAutoRestart(XWhiteboard_restore *InstancePtr);
u32 XWhiteboard_restore_Get_return(XWhiteboard_restore *InstancePtr);

void XWhiteboard_restore_Set_input_r(XWhiteboard_restore *InstancePtr, u64 Data);
u64 XWhiteboard_restore_Get_input_r(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_output_r(XWhiteboard_restore *InstancePtr, u64 Data);
u64 XWhiteboard_restore_Get_output_r(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_background(XWhiteboard_restore *InstancePtr, u64 Data);
u64 XWhiteboard_restore_Get_background(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_previous(XWhiteboard_restore *InstancePtr, u64 Data);
u64 XWhiteboard_restore_Get_previous(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_pixel_quiet(XWhiteboard_restore *InstancePtr, u64 Data);
u64 XWhiteboard_restore_Get_pixel_quiet(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_block_state(XWhiteboard_restore *InstancePtr, u64 Data);
u64 XWhiteboard_restore_Get_block_state(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_roi(XWhiteboard_restore *InstancePtr, u64 Data);
u64 XWhiteboard_restore_Get_roi(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_width(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_width(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_height(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_height(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_initialize(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_initialize(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_bgr(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_bgr(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_delta(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_delta(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_quiet_delta(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_quiet_delta(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_dense(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_dense(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_weak_threshold(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_weak_threshold(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_hold(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_hold(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_stable_r(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_stable_r(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_quiet_max(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_quiet_max(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_chalk_min(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_chalk_min(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_chalk_spread(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_chalk_spread(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_fine_min(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_fine_min(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_fine_spread(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_fine_spread(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_Set_red_bias(XWhiteboard_restore *InstancePtr, u32 Data);
u32 XWhiteboard_restore_Get_red_bias(XWhiteboard_restore *InstancePtr);

void XWhiteboard_restore_InterruptGlobalEnable(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_InterruptGlobalDisable(XWhiteboard_restore *InstancePtr);
void XWhiteboard_restore_InterruptEnable(XWhiteboard_restore *InstancePtr, u32 Mask);
void XWhiteboard_restore_InterruptDisable(XWhiteboard_restore *InstancePtr, u32 Mask);
void XWhiteboard_restore_InterruptClear(XWhiteboard_restore *InstancePtr, u32 Mask);
u32 XWhiteboard_restore_InterruptGetEnabled(XWhiteboard_restore *InstancePtr);
u32 XWhiteboard_restore_InterruptGetStatus(XWhiteboard_restore *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
