# Definitional proc to organize widgets for parameters.
proc init_gui { IPINST } {
  ipgui::add_param $IPINST -name "Component_Name"
  #Adding Page
  set Page_0 [ipgui::add_page $IPINST -name "Page 0"]
  #Adding Group
  set group_0 [ipgui::add_group $IPINST -name "group 0" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_frame_in}]
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_ENABLE_ID_PORTS" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_ID_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_DATA_WIDTH" -parent ${group_0} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_ENABLE_USER_PORTS" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_AWUSER_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_WUSER_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_BUSER_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_ARUSER_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_RUSER_WIDTH" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_USER_VALUE" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_PROT_VALUE" -parent ${group_0}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_IN_CACHE_VALUE" -parent ${group_0}

  #Adding Group
  set group_1 [ipgui::add_group $IPINST -name "group 1" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_frame_out}]
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_ENABLE_ID_PORTS" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_ID_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_DATA_WIDTH" -parent ${group_1} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_ENABLE_USER_PORTS" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_AWUSER_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_WUSER_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_BUSER_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_ARUSER_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_RUSER_WIDTH" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_USER_VALUE" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_PROT_VALUE" -parent ${group_1}
  ipgui::add_param $IPINST -name "C_M_AXI_FRAME_OUT_CACHE_VALUE" -parent ${group_1}

  #Adding Group
  set group_2 [ipgui::add_group $IPINST -name "group 2" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_history}]
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_ENABLE_ID_PORTS" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_ID_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_DATA_WIDTH" -parent ${group_2} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_ENABLE_USER_PORTS" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_AWUSER_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_WUSER_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_BUSER_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_ARUSER_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_RUSER_WIDTH" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_USER_VALUE" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_PROT_VALUE" -parent ${group_2}
  ipgui::add_param $IPINST -name "C_M_AXI_HISTORY_CACHE_VALUE" -parent ${group_2}

  #Adding Group
  set group_3 [ipgui::add_group $IPINST -name "group 3" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_previous_frame}]
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_ENABLE_ID_PORTS" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_ID_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH" -parent ${group_3} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_ENABLE_USER_PORTS" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_USER_VALUE" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_PROT_VALUE" -parent ${group_3}
  ipgui::add_param $IPINST -name "C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE" -parent ${group_3}

  #Adding Group
  set group_4 [ipgui::add_group $IPINST -name "group 4" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_pixel_state}]
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_ENABLE_ID_PORTS" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_ID_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_DATA_WIDTH" -parent ${group_4} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_ENABLE_USER_PORTS" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_AWUSER_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_WUSER_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_BUSER_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_ARUSER_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_RUSER_WIDTH" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_USER_VALUE" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_PROT_VALUE" -parent ${group_4}
  ipgui::add_param $IPINST -name "C_M_AXI_PIXEL_STATE_CACHE_VALUE" -parent ${group_4}

  #Adding Group
  set group_5 [ipgui::add_group $IPINST -name "group 5" -parent ${Page_0} -display_name {AXI4 Master Interface m_axi_block_memory}]
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_ENABLE_ID_PORTS" -parent ${group_5}
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_ID_WIDTH" -parent ${group_5}
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_DATA_WIDTH" -parent ${group_5} -widget comboBox
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_ENABLE_USER_PORTS" -parent ${group_5}
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH" -parent ${group_5}
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH" -parent ${group_5}
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH" -parent ${group_5}
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH" -parent ${group_5}
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH" -parent ${group_5}
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_USER_VALUE" -parent ${group_5}
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_PROT_VALUE" -parent ${group_5}
  ipgui::add_param $IPINST -name "C_M_AXI_BLOCK_MEMORY_CACHE_VALUE" -parent ${group_5}



}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_FRAME_IN_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_FRAME_IN_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_FRAME_IN_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_FRAME_IN_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_ID_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_ID_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_IN_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_ID_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_IN_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_DATA_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_IN_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_DATA_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_IN_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_FRAME_IN_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_FRAME_IN_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_FRAME_IN_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_FRAME_IN_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_IN_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_IN_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_IN_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_IN_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_IN_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_IN_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_IN_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_IN_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_IN_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_IN_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_IN_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_USER_VALUE { PARAM_VALUE.C_M_AXI_FRAME_IN_USER_VALUE } {
	# Procedure called to update C_M_AXI_FRAME_IN_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_USER_VALUE { PARAM_VALUE.C_M_AXI_FRAME_IN_USER_VALUE } {
	# Procedure called to validate C_M_AXI_FRAME_IN_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_PROT_VALUE { PARAM_VALUE.C_M_AXI_FRAME_IN_PROT_VALUE } {
	# Procedure called to update C_M_AXI_FRAME_IN_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_PROT_VALUE { PARAM_VALUE.C_M_AXI_FRAME_IN_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_FRAME_IN_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_IN_CACHE_VALUE { PARAM_VALUE.C_M_AXI_FRAME_IN_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_FRAME_IN_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_IN_CACHE_VALUE { PARAM_VALUE.C_M_AXI_FRAME_IN_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_FRAME_IN_CACHE_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_FRAME_OUT_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_FRAME_OUT_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_FRAME_OUT_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_ID_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_ID_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_OUT_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_ID_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_DATA_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_OUT_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_DATA_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_FRAME_OUT_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_FRAME_OUT_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_FRAME_OUT_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_OUT_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_OUT_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_OUT_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_OUT_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_FRAME_OUT_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_FRAME_OUT_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_USER_VALUE { PARAM_VALUE.C_M_AXI_FRAME_OUT_USER_VALUE } {
	# Procedure called to update C_M_AXI_FRAME_OUT_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_USER_VALUE { PARAM_VALUE.C_M_AXI_FRAME_OUT_USER_VALUE } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_PROT_VALUE { PARAM_VALUE.C_M_AXI_FRAME_OUT_PROT_VALUE } {
	# Procedure called to update C_M_AXI_FRAME_OUT_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_PROT_VALUE { PARAM_VALUE.C_M_AXI_FRAME_OUT_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_FRAME_OUT_CACHE_VALUE { PARAM_VALUE.C_M_AXI_FRAME_OUT_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_FRAME_OUT_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_FRAME_OUT_CACHE_VALUE { PARAM_VALUE.C_M_AXI_FRAME_OUT_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_FRAME_OUT_CACHE_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_HISTORY_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_HISTORY_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_HISTORY_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_HISTORY_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_ID_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_ID_WIDTH } {
	# Procedure called to update C_M_AXI_HISTORY_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_ID_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_HISTORY_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_DATA_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_HISTORY_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_DATA_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_HISTORY_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_HISTORY_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_HISTORY_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_HISTORY_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_HISTORY_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_HISTORY_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_HISTORY_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_HISTORY_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_HISTORY_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_HISTORY_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_HISTORY_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_HISTORY_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_HISTORY_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_HISTORY_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_HISTORY_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_HISTORY_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_USER_VALUE { PARAM_VALUE.C_M_AXI_HISTORY_USER_VALUE } {
	# Procedure called to update C_M_AXI_HISTORY_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_USER_VALUE { PARAM_VALUE.C_M_AXI_HISTORY_USER_VALUE } {
	# Procedure called to validate C_M_AXI_HISTORY_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_PROT_VALUE { PARAM_VALUE.C_M_AXI_HISTORY_PROT_VALUE } {
	# Procedure called to update C_M_AXI_HISTORY_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_PROT_VALUE { PARAM_VALUE.C_M_AXI_HISTORY_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_HISTORY_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_HISTORY_CACHE_VALUE { PARAM_VALUE.C_M_AXI_HISTORY_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_HISTORY_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_HISTORY_CACHE_VALUE { PARAM_VALUE.C_M_AXI_HISTORY_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_HISTORY_CACHE_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ID_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ID_WIDTH } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ID_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_USER_VALUE { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_USER_VALUE } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_USER_VALUE { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_USER_VALUE } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_PROT_VALUE { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_PROT_VALUE } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_PROT_VALUE { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE { PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_PIXEL_STATE_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_PIXEL_STATE_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_ID_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_ID_WIDTH } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_ID_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_DATA_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_DATA_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_PIXEL_STATE_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_PIXEL_STATE_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_PIXEL_STATE_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_USER_VALUE { PARAM_VALUE.C_M_AXI_PIXEL_STATE_USER_VALUE } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_USER_VALUE { PARAM_VALUE.C_M_AXI_PIXEL_STATE_USER_VALUE } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_PROT_VALUE { PARAM_VALUE.C_M_AXI_PIXEL_STATE_PROT_VALUE } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_PROT_VALUE { PARAM_VALUE.C_M_AXI_PIXEL_STATE_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_PIXEL_STATE_CACHE_VALUE { PARAM_VALUE.C_M_AXI_PIXEL_STATE_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_PIXEL_STATE_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_PIXEL_STATE_CACHE_VALUE { PARAM_VALUE.C_M_AXI_PIXEL_STATE_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_PIXEL_STATE_CACHE_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ENABLE_ID_PORTS } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_ENABLE_ID_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ENABLE_ID_PORTS { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ENABLE_ID_PORTS } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_ENABLE_ID_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ID_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ID_WIDTH } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_ID_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ID_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ID_WIDTH } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_ID_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_DATA_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_DATA_WIDTH } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_DATA_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_DATA_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_DATA_WIDTH } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_DATA_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ENABLE_USER_PORTS } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_ENABLE_USER_PORTS when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ENABLE_USER_PORTS { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ENABLE_USER_PORTS } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_ENABLE_USER_PORTS
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_USER_VALUE { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_USER_VALUE } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_USER_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_USER_VALUE { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_USER_VALUE } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_USER_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_PROT_VALUE { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_PROT_VALUE } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_PROT_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_PROT_VALUE { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_PROT_VALUE } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_PROT_VALUE
	return true
}

proc update_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_CACHE_VALUE { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_CACHE_VALUE } {
	# Procedure called to update C_M_AXI_BLOCK_MEMORY_CACHE_VALUE when any of the dependent parameters in the arguments change
}

proc validate_PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_CACHE_VALUE { PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_CACHE_VALUE } {
	# Procedure called to validate C_M_AXI_BLOCK_MEMORY_CACHE_VALUE
	return true
}


proc update_MODELPARAM_VALUE.C_S_AXI_CONTROL_ADDR_WIDTH { MODELPARAM_VALUE.C_S_AXI_CONTROL_ADDR_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	# WARNING: There is no corresponding user parameter named "C_S_AXI_CONTROL_ADDR_WIDTH". Setting updated value from the model parameter.
set_property value 8 ${MODELPARAM_VALUE.C_S_AXI_CONTROL_ADDR_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_IN_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_IN_ID_WIDTH PARAM_VALUE.C_M_AXI_FRAME_IN_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_IN_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_IN_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_IN_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_IN_DATA_WIDTH PARAM_VALUE.C_M_AXI_FRAME_IN_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_IN_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_IN_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_IN_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_IN_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_FRAME_IN_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_IN_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_IN_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_IN_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_IN_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_FRAME_IN_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_IN_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_IN_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_IN_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_IN_WUSER_WIDTH PARAM_VALUE.C_M_AXI_FRAME_IN_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_IN_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_IN_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_IN_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_IN_RUSER_WIDTH PARAM_VALUE.C_M_AXI_FRAME_IN_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_IN_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_IN_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_IN_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_IN_BUSER_WIDTH PARAM_VALUE.C_M_AXI_FRAME_IN_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_IN_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_IN_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_IN_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_FRAME_IN_USER_VALUE PARAM_VALUE.C_M_AXI_FRAME_IN_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_IN_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_IN_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_IN_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_FRAME_IN_PROT_VALUE PARAM_VALUE.C_M_AXI_FRAME_IN_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_IN_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_IN_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_IN_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_FRAME_IN_CACHE_VALUE PARAM_VALUE.C_M_AXI_FRAME_IN_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_IN_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_IN_CACHE_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_ID_WIDTH PARAM_VALUE.C_M_AXI_FRAME_OUT_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_OUT_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_DATA_WIDTH PARAM_VALUE.C_M_AXI_FRAME_OUT_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_OUT_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_FRAME_OUT_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_OUT_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_FRAME_OUT_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_OUT_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_WUSER_WIDTH PARAM_VALUE.C_M_AXI_FRAME_OUT_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_OUT_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_RUSER_WIDTH PARAM_VALUE.C_M_AXI_FRAME_OUT_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_OUT_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_BUSER_WIDTH PARAM_VALUE.C_M_AXI_FRAME_OUT_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_OUT_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_USER_VALUE PARAM_VALUE.C_M_AXI_FRAME_OUT_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_OUT_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_PROT_VALUE PARAM_VALUE.C_M_AXI_FRAME_OUT_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_OUT_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_CACHE_VALUE PARAM_VALUE.C_M_AXI_FRAME_OUT_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_FRAME_OUT_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_FRAME_OUT_CACHE_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_HISTORY_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_HISTORY_ID_WIDTH PARAM_VALUE.C_M_AXI_HISTORY_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_HISTORY_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_HISTORY_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_HISTORY_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_HISTORY_DATA_WIDTH PARAM_VALUE.C_M_AXI_HISTORY_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_HISTORY_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_HISTORY_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_HISTORY_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_HISTORY_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_HISTORY_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_HISTORY_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_HISTORY_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_HISTORY_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_HISTORY_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_HISTORY_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_HISTORY_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_HISTORY_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_HISTORY_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_HISTORY_WUSER_WIDTH PARAM_VALUE.C_M_AXI_HISTORY_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_HISTORY_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_HISTORY_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_HISTORY_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_HISTORY_RUSER_WIDTH PARAM_VALUE.C_M_AXI_HISTORY_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_HISTORY_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_HISTORY_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_HISTORY_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_HISTORY_BUSER_WIDTH PARAM_VALUE.C_M_AXI_HISTORY_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_HISTORY_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_HISTORY_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_HISTORY_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_HISTORY_USER_VALUE PARAM_VALUE.C_M_AXI_HISTORY_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_HISTORY_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_HISTORY_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_HISTORY_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_HISTORY_PROT_VALUE PARAM_VALUE.C_M_AXI_HISTORY_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_HISTORY_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_HISTORY_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_HISTORY_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_HISTORY_CACHE_VALUE PARAM_VALUE.C_M_AXI_HISTORY_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_HISTORY_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_HISTORY_CACHE_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ID_WIDTH PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_USER_VALUE PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_PROT_VALUE PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_PREVIOUS_FRAME_CACHE_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_ID_WIDTH PARAM_VALUE.C_M_AXI_PIXEL_STATE_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PIXEL_STATE_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_DATA_WIDTH PARAM_VALUE.C_M_AXI_PIXEL_STATE_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PIXEL_STATE_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_PIXEL_STATE_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PIXEL_STATE_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_PIXEL_STATE_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PIXEL_STATE_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_WUSER_WIDTH PARAM_VALUE.C_M_AXI_PIXEL_STATE_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PIXEL_STATE_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_RUSER_WIDTH PARAM_VALUE.C_M_AXI_PIXEL_STATE_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PIXEL_STATE_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_BUSER_WIDTH PARAM_VALUE.C_M_AXI_PIXEL_STATE_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PIXEL_STATE_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_USER_VALUE PARAM_VALUE.C_M_AXI_PIXEL_STATE_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PIXEL_STATE_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_PROT_VALUE PARAM_VALUE.C_M_AXI_PIXEL_STATE_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PIXEL_STATE_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_CACHE_VALUE PARAM_VALUE.C_M_AXI_PIXEL_STATE_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_PIXEL_STATE_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_PIXEL_STATE_CACHE_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ID_WIDTH { MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ID_WIDTH PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ID_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ID_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ID_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_DATA_WIDTH { MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_DATA_WIDTH PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_DATA_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_DATA_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_DATA_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_AWUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_ARUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_WUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_RUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH { MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH}] ${MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_BUSER_WIDTH}
}

proc update_MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_USER_VALUE { MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_USER_VALUE PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_USER_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_USER_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_USER_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_PROT_VALUE { MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_PROT_VALUE PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_PROT_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_PROT_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_PROT_VALUE}
}

proc update_MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_CACHE_VALUE { MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_CACHE_VALUE PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_CACHE_VALUE } {
	# Procedure called to set VHDL generic/Verilog parameter value(s) based on TCL parameter value
	set_property value [get_property value ${PARAM_VALUE.C_M_AXI_BLOCK_MEMORY_CACHE_VALUE}] ${MODELPARAM_VALUE.C_M_AXI_BLOCK_MEMORY_CACHE_VALUE}
}

