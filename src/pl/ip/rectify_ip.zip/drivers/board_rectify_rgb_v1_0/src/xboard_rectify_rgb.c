// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xboard_rectify_rgb.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XBoard_rectify_rgb_CfgInitialize(XBoard_rectify_rgb *InstancePtr, XBoard_rectify_rgb_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XBoard_rectify_rgb_Start(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_AP_CTRL) & 0x80;
    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XBoard_rectify_rgb_IsDone(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XBoard_rectify_rgb_IsIdle(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XBoard_rectify_rgb_IsReady(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XBoard_rectify_rgb_EnableAutoRestart(XBoard_rectify_rgb *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XBoard_rectify_rgb_DisableAutoRestart(XBoard_rectify_rgb *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_AP_CTRL, 0);
}

void XBoard_rectify_rgb_Set_src(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_SRC_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_src(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_SRC_DATA);
    return Data;
}

void XBoard_rectify_rgb_Set_dst(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_DST_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_dst(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_DST_DATA);
    return Data;
}

void XBoard_rectify_rgb_Set_status(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_STATUS_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_status(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_STATUS_DATA);
    return Data;
}

void XBoard_rectify_rgb_Set_hint(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_HINT_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_hint(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_HINT_DATA);
    return Data;
}

void XBoard_rectify_rgb_Set_corners(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_CORNERS_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_corners(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_CORNERS_DATA);
    return Data;
}

void XBoard_rectify_rgb_Set_binary_enable(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_BINARY_ENABLE_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_binary_enable(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_BINARY_ENABLE_DATA);
    return Data;
}

void XBoard_rectify_rgb_Set_mode(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_MODE_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_mode(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_MODE_DATA);
    return Data;
}

void XBoard_rectify_rgb_Set_threshold(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_THRESHOLD_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_threshold(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_THRESHOLD_DATA);
    return Data;
}

void XBoard_rectify_rgb_Set_bgr(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_BGR_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_bgr(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_BGR_DATA);
    return Data;
}

void XBoard_rectify_rgb_Set_geometry(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_GEOMETRY_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_geometry(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_GEOMETRY_DATA);
    return Data;
}

void XBoard_rectify_rgb_Set_diagnostics(XBoard_rectify_rgb *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_DIAGNOSTICS_DATA, Data);
}

u32 XBoard_rectify_rgb_Get_diagnostics(XBoard_rectify_rgb *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_DIAGNOSTICS_DATA);
    return Data;
}

void XBoard_rectify_rgb_InterruptGlobalEnable(XBoard_rectify_rgb *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_GIE, 1);
}

void XBoard_rectify_rgb_InterruptGlobalDisable(XBoard_rectify_rgb *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_GIE, 0);
}

void XBoard_rectify_rgb_InterruptEnable(XBoard_rectify_rgb *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_IER);
    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_IER, Register | Mask);
}

void XBoard_rectify_rgb_InterruptDisable(XBoard_rectify_rgb *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_IER);
    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_IER, Register & (~Mask));
}

void XBoard_rectify_rgb_InterruptClear(XBoard_rectify_rgb *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_rectify_rgb_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_ISR, Mask);
}

u32 XBoard_rectify_rgb_InterruptGetEnabled(XBoard_rectify_rgb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_IER);
}

u32 XBoard_rectify_rgb_InterruptGetStatus(XBoard_rectify_rgb *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XBoard_rectify_rgb_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_RECTIFY_RGB_CONTROL_ADDR_ISR);
}

