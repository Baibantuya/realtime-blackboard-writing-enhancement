// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xboard_rectify_rgb.h"

extern XBoard_rectify_rgb_Config XBoard_rectify_rgb_ConfigTable[];

#ifdef SDT
XBoard_rectify_rgb_Config *XBoard_rectify_rgb_LookupConfig(UINTPTR BaseAddress) {
	XBoard_rectify_rgb_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XBoard_rectify_rgb_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XBoard_rectify_rgb_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XBoard_rectify_rgb_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XBoard_rectify_rgb_Initialize(XBoard_rectify_rgb *InstancePtr, UINTPTR BaseAddress) {
	XBoard_rectify_rgb_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XBoard_rectify_rgb_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XBoard_rectify_rgb_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XBoard_rectify_rgb_Config *XBoard_rectify_rgb_LookupConfig(u16 DeviceId) {
	XBoard_rectify_rgb_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XBOARD_RECTIFY_RGB_NUM_INSTANCES; Index++) {
		if (XBoard_rectify_rgb_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XBoard_rectify_rgb_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XBoard_rectify_rgb_Initialize(XBoard_rectify_rgb *InstancePtr, u16 DeviceId) {
	XBoard_rectify_rgb_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XBoard_rectify_rgb_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XBoard_rectify_rgb_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

