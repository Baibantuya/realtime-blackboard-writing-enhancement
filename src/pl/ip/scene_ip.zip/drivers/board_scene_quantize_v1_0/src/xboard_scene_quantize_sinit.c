// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef __linux__

#include "xstatus.h"
#ifdef SDT
#include "xparameters.h"
#endif
#include "xboard_scene_quantize.h"

extern XBoard_scene_quantize_Config XBoard_scene_quantize_ConfigTable[];

#ifdef SDT
XBoard_scene_quantize_Config *XBoard_scene_quantize_LookupConfig(UINTPTR BaseAddress) {
	XBoard_scene_quantize_Config *ConfigPtr = NULL;

	int Index;

	for (Index = (u32)0x0; XBoard_scene_quantize_ConfigTable[Index].Name != NULL; Index++) {
		if (!BaseAddress || XBoard_scene_quantize_ConfigTable[Index].Control_BaseAddress == BaseAddress) {
			ConfigPtr = &XBoard_scene_quantize_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XBoard_scene_quantize_Initialize(XBoard_scene_quantize *InstancePtr, UINTPTR BaseAddress) {
	XBoard_scene_quantize_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XBoard_scene_quantize_LookupConfig(BaseAddress);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XBoard_scene_quantize_CfgInitialize(InstancePtr, ConfigPtr);
}
#else
XBoard_scene_quantize_Config *XBoard_scene_quantize_LookupConfig(u16 DeviceId) {
	XBoard_scene_quantize_Config *ConfigPtr = NULL;

	int Index;

	for (Index = 0; Index < XPAR_XBOARD_SCENE_QUANTIZE_NUM_INSTANCES; Index++) {
		if (XBoard_scene_quantize_ConfigTable[Index].DeviceId == DeviceId) {
			ConfigPtr = &XBoard_scene_quantize_ConfigTable[Index];
			break;
		}
	}

	return ConfigPtr;
}

int XBoard_scene_quantize_Initialize(XBoard_scene_quantize *InstancePtr, u16 DeviceId) {
	XBoard_scene_quantize_Config *ConfigPtr;

	Xil_AssertNonvoid(InstancePtr != NULL);

	ConfigPtr = XBoard_scene_quantize_LookupConfig(DeviceId);
	if (ConfigPtr == NULL) {
		InstancePtr->IsReady = 0;
		return (XST_DEVICE_NOT_FOUND);
	}

	return XBoard_scene_quantize_CfgInitialize(InstancePtr, ConfigPtr);
}
#endif

#endif

