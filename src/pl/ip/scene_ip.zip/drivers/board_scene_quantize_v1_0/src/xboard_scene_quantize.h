// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XBOARD_SCENE_QUANTIZE_H
#define XBOARD_SCENE_QUANTIZE_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xboard_scene_quantize_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u32 Control_BaseAddress;
} XBoard_scene_quantize_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XBoard_scene_quantize;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XBoard_scene_quantize_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XBoard_scene_quantize_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XBoard_scene_quantize_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XBoard_scene_quantize_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XBoard_scene_quantize_Initialize(XBoard_scene_quantize *InstancePtr, UINTPTR BaseAddress);
XBoard_scene_quantize_Config* XBoard_scene_quantize_LookupConfig(UINTPTR BaseAddress);
#else
int XBoard_scene_quantize_Initialize(XBoard_scene_quantize *InstancePtr, u16 DeviceId);
XBoard_scene_quantize_Config* XBoard_scene_quantize_LookupConfig(u16 DeviceId);
#endif
int XBoard_scene_quantize_CfgInitialize(XBoard_scene_quantize *InstancePtr, XBoard_scene_quantize_Config *ConfigPtr);
#else
int XBoard_scene_quantize_Initialize(XBoard_scene_quantize *InstancePtr, const char* InstanceName);
int XBoard_scene_quantize_Release(XBoard_scene_quantize *InstancePtr);
#endif

void XBoard_scene_quantize_Start(XBoard_scene_quantize *InstancePtr);
u32 XBoard_scene_quantize_IsDone(XBoard_scene_quantize *InstancePtr);
u32 XBoard_scene_quantize_IsIdle(XBoard_scene_quantize *InstancePtr);
u32 XBoard_scene_quantize_IsReady(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_EnableAutoRestart(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_DisableAutoRestart(XBoard_scene_quantize *InstancePtr);
u32 XBoard_scene_quantize_Get_return(XBoard_scene_quantize *InstancePtr);

void XBoard_scene_quantize_Set_src(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_src(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_canvas_in(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_canvas_in(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_canvas_out(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_canvas_out(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_metadata(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_metadata(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_dst(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_dst(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_width(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_width(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_height(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_height(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_dst_stride(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_dst_stride(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_frame_cookie(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_frame_cookie(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_metadata_cookie(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_metadata_cookie(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_control_r(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_control_r(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_order(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_order(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_ink_delta(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_ink_delta(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_erase_delta(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_erase_delta(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_Set_color_margin(XBoard_scene_quantize *InstancePtr, u32 Data);
u32 XBoard_scene_quantize_Get_color_margin(XBoard_scene_quantize *InstancePtr);

void XBoard_scene_quantize_InterruptGlobalEnable(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_InterruptGlobalDisable(XBoard_scene_quantize *InstancePtr);
void XBoard_scene_quantize_InterruptEnable(XBoard_scene_quantize *InstancePtr, u32 Mask);
void XBoard_scene_quantize_InterruptDisable(XBoard_scene_quantize *InstancePtr, u32 Mask);
void XBoard_scene_quantize_InterruptClear(XBoard_scene_quantize *InstancePtr, u32 Mask);
u32 XBoard_scene_quantize_InterruptGetEnabled(XBoard_scene_quantize *InstancePtr);
u32 XBoard_scene_quantize_InterruptGetStatus(XBoard_scene_quantize *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
