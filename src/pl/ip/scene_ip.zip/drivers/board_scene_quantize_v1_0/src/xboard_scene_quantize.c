// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
/***************************** Include Files *********************************/
#include "xboard_scene_quantize.h"

/************************** Function Implementation *************************/
#ifndef __linux__
int XBoard_scene_quantize_CfgInitialize(XBoard_scene_quantize *InstancePtr, XBoard_scene_quantize_Config *ConfigPtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(ConfigPtr != NULL);

    InstancePtr->Control_BaseAddress = ConfigPtr->Control_BaseAddress;
    InstancePtr->IsReady = XIL_COMPONENT_IS_READY;

    return XST_SUCCESS;
}
#endif

void XBoard_scene_quantize_Start(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_AP_CTRL) & 0x80;
    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_AP_CTRL, Data | 0x01);
}

u32 XBoard_scene_quantize_IsDone(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 1) & 0x1;
}

u32 XBoard_scene_quantize_IsIdle(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_AP_CTRL);
    return (Data >> 2) & 0x1;
}

u32 XBoard_scene_quantize_IsReady(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_AP_CTRL);
    // check ap_start to see if the pcore is ready for next input
    return !(Data & 0x1);
}

void XBoard_scene_quantize_EnableAutoRestart(XBoard_scene_quantize *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_AP_CTRL, 0x80);
}

void XBoard_scene_quantize_DisableAutoRestart(XBoard_scene_quantize *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_AP_CTRL, 0);
}

u32 XBoard_scene_quantize_Get_return(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_AP_RETURN);
    return Data;
}
void XBoard_scene_quantize_Set_src(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_SRC_DATA, Data);
}

u32 XBoard_scene_quantize_Get_src(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_SRC_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_canvas_in(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_CANVAS_IN_DATA, Data);
}

u32 XBoard_scene_quantize_Get_canvas_in(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_CANVAS_IN_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_canvas_out(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_CANVAS_OUT_DATA, Data);
}

u32 XBoard_scene_quantize_Get_canvas_out(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_CANVAS_OUT_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_metadata(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_METADATA_DATA, Data);
}

u32 XBoard_scene_quantize_Get_metadata(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_METADATA_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_dst(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_DST_DATA, Data);
}

u32 XBoard_scene_quantize_Get_dst(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_DST_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_width(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_WIDTH_DATA, Data);
}

u32 XBoard_scene_quantize_Get_width(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_WIDTH_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_height(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_HEIGHT_DATA, Data);
}

u32 XBoard_scene_quantize_Get_height(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_HEIGHT_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_dst_stride(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_DST_STRIDE_DATA, Data);
}

u32 XBoard_scene_quantize_Get_dst_stride(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_DST_STRIDE_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_frame_cookie(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_FRAME_COOKIE_DATA, Data);
}

u32 XBoard_scene_quantize_Get_frame_cookie(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_FRAME_COOKIE_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_metadata_cookie(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_METADATA_COOKIE_DATA, Data);
}

u32 XBoard_scene_quantize_Get_metadata_cookie(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_METADATA_COOKIE_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_control_r(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_CONTROL_R_DATA, Data);
}

u32 XBoard_scene_quantize_Get_control_r(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_CONTROL_R_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_order(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_ORDER_DATA, Data);
}

u32 XBoard_scene_quantize_Get_order(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_ORDER_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_ink_delta(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_INK_DELTA_DATA, Data);
}

u32 XBoard_scene_quantize_Get_ink_delta(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_INK_DELTA_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_erase_delta(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_ERASE_DELTA_DATA, Data);
}

u32 XBoard_scene_quantize_Get_erase_delta(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_ERASE_DELTA_DATA);
    return Data;
}

void XBoard_scene_quantize_Set_color_margin(XBoard_scene_quantize *InstancePtr, u32 Data) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_COLOR_MARGIN_DATA, Data);
}

u32 XBoard_scene_quantize_Get_color_margin(XBoard_scene_quantize *InstancePtr) {
    u32 Data;

    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Data = XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_COLOR_MARGIN_DATA);
    return Data;
}

void XBoard_scene_quantize_InterruptGlobalEnable(XBoard_scene_quantize *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_GIE, 1);
}

void XBoard_scene_quantize_InterruptGlobalDisable(XBoard_scene_quantize *InstancePtr) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_GIE, 0);
}

void XBoard_scene_quantize_InterruptEnable(XBoard_scene_quantize *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_IER);
    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_IER, Register | Mask);
}

void XBoard_scene_quantize_InterruptDisable(XBoard_scene_quantize *InstancePtr, u32 Mask) {
    u32 Register;

    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    Register =  XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_IER);
    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_IER, Register & (~Mask));
}

void XBoard_scene_quantize_InterruptClear(XBoard_scene_quantize *InstancePtr, u32 Mask) {
    Xil_AssertVoid(InstancePtr != NULL);
    Xil_AssertVoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    XBoard_scene_quantize_WriteReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_ISR, Mask);
}

u32 XBoard_scene_quantize_InterruptGetEnabled(XBoard_scene_quantize *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_IER);
}

u32 XBoard_scene_quantize_InterruptGetStatus(XBoard_scene_quantize *InstancePtr) {
    Xil_AssertNonvoid(InstancePtr != NULL);
    Xil_AssertNonvoid(InstancePtr->IsReady == XIL_COMPONENT_IS_READY);

    return XBoard_scene_quantize_ReadReg(InstancePtr->Control_BaseAddress, XBOARD_SCENE_QUANTIZE_CONTROL_ADDR_ISR);
}

