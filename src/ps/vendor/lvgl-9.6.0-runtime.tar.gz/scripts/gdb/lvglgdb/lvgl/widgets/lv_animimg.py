"""
Auto-generated wrapper for lv_animimg_t.

Do not edit manually. Regenerate from the GDB script root with:
    python3 scripts/generate_all.py
"""

from .lv_image import LVImage
from ._helpers import ptr_or_none, safe_wrapper


class LVAnimimg(LVImage):
    """LVGL animimage widget (lv_animimg_t)."""

    def __init__(self, obj):
        super().__init__(obj)
        self._wv_lv_animimg_t = self.cast("lv_animimg_t", ptr=True) or self
        self._wv = self._wv_lv_animimg_t

    @property
    def anim(self):
        return safe_wrapper(self._wv_lv_animimg_t, "anim", "lvglgdb.lvgl.misc.lv_anim", "LVAnim")

    @property
    def dsc(self):
        return ptr_or_none(self._wv_lv_animimg_t.safe_field("dsc"))

    @property
    def pic_count(self):
        return int(self._wv_lv_animimg_t.safe_field("pic_count", 0))

    def snapshot(self, include_children=False, include_styles=False):
        """Snapshot with widget-specific fields in widget_data."""
        s = super().snapshot(include_children=include_children, include_styles=include_styles)
        d = s.get('widget_data') or {}
        d["anim"] = self.anim
        d["dsc"] = self.dsc
        d["pic_count"] = self.pic_count
        s['widget_data'] = d
        return s
