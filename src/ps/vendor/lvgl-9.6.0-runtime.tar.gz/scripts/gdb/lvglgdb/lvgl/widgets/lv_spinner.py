"""
Auto-generated wrapper for lv_spinner_t.

Do not edit manually. Regenerate from the GDB script root with:
    python3 scripts/generate_all.py
"""

from .lv_arc import LVArc


class LVSpinner(LVArc):
    """LVGL spinner widget (lv_spinner_t)."""

    def __init__(self, obj):
        super().__init__(obj)
        self._wv_lv_spinner_t = self.cast("lv_spinner_t", ptr=True) or self
        self._wv = self._wv_lv_spinner_t

    @property
    def duration(self):
        """Anim duration in ms"""
        return int(self._wv_lv_spinner_t.safe_field("duration", 0))

    @property
    def angle(self):
        """Anim angle in degrees"""
        return int(self._wv_lv_spinner_t.safe_field("angle", 0))

    def snapshot(self, include_children=False, include_styles=False):
        """Snapshot with widget-specific fields in widget_data."""
        s = super().snapshot(include_children=include_children, include_styles=include_styles)
        d = s.get('widget_data') or {}
        d["duration"] = self.duration
        d["angle"] = self.angle
        s['widget_data'] = d
        return s
