// Isolated simulator diagnostic, not the board DUT or acceptance testbench.
module queue_probe;
  bit [31:0] words[$];
  integer count;
  initial begin
    if (!$value$plusargs("count=%d", count)) count = 1048576;
    if (count < 1 || count > 1555200) $fatal(1, "Invalid diagnostic count");
    $display("QUEUE_PROBE_BEGIN count=%0d", count);
    for (int i=0; i<count; i++) begin
      words.push_back(i);
      if ((i & 65535)==65535) $display("QUEUE_PROBE_PROGRESS %0d", i+1);
    end
    if (words.size()!=count) $fatal(1, "Queue size mismatch");
    for (int j=0; j<count; j++)
      if(words[j]!==j) $fatal(1, "Queue content mismatch at %0d", j);
    $display("QUEUE_PROBE_PASS count=%0d", count);
    $finish;
  end
endmodule
