$ErrorActionPreference='Stop'
Set-Location -LiteralPath $PSScriptRoot
& 'D:/Xillinx/2025.2/Vivado/bin/xvlog.bat' --sv queue_probe.sv *> compile.log
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
& 'D:/Xillinx/2025.2/Vivado/bin/xelab.bat' queue_probe -s probe *> elaborate.log
if($LASTEXITCODE -ne 0){exit $LASTEXITCODE}
& 'D:/Xillinx/2025.2/Vivado/bin/xsim.bat' probe -R *> simulate.log
$taskExit=$LASTEXITCODE
@{exit_code=$taskExit;scope='Synthetic queue diagnostic only'} | ConvertTo-Json | Set-Content -LiteralPath status.json -Encoding utf8
Get-Content -LiteralPath simulate.log -Tail 10
exit $taskExit
