$ErrorActionPreference = 'Stop'
$env:PATH = 'D:\Xillinx\2025.2\Vivado\bin;' + $env:PATH
Set-Location -LiteralPath $PSScriptRoot
& $env:ComSpec /d /c run_xsim.bat *> console.log
$code = $LASTEXITCODE
@{ exit_code = $code; completed_at = (Get-Date).ToString('o') } | ConvertTo-Json | Set-Content -LiteralPath status.json
exit $code
