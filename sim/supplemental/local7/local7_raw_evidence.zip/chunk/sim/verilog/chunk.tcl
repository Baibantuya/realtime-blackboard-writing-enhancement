set completed 0
for {set segment 0} {$segment < 10000} {incr segment} {
    run 100 us
    set done_count [get_value -radix unsigned /apatb_board_rectify_rgb_top/finish_cnt]
    puts "L7_CHUNK segment=$segment completed=$done_count"
    if {$done_count >= 1} {set completed 1; break}
}
if {!$completed} {puts "L7_CHUNK_LIMIT_NOT_PASS"; quit -code 3}
puts "L7_CHUNK_TRANSACTION_COMPLETE"
quit
