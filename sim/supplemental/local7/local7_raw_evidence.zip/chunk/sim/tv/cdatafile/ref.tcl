set depth_list {
  {bgr 1}
  {binary_enable 1}
  {corners 1}
  {diagnostics 1}
  {dst 1}
  {geometry 1}
  {gmem0 1036800}
  {gmem1 1036800}
  {gmem2 42}
  {hint 1}
  {mode 1}
  {src 1}
  {status 1}
  {threshold 1}
}
set trans_depth {
  {corners { 4 } gmem2}
  {diagnostics { 16 } gmem2}
  {dst { 1036800 } gmem1}
  {geometry { 20 } gmem2}
  {hint { 1 } gmem2}
  {src { 1036800 } gmem0}
  {status { 1 } gmem2}
}
set containsVLA 0
set trans_num 1
