$ErrorActionPreference='Stop'
if($env:XILINX_PATH -or $env:MYVIVADO){throw 'Unexpected overlay'}
Set-Location -LiteralPath $PSScriptRoot
if(Test-Path -LiteralPath p){throw 'Preserve previous evidence'}
& 'D:/Xillinx/2025.2/Vitis/bin/vitis-run.bat' --mode hls --tcl run.tcl *> run.log
$taskExit=$LASTEXITCODE
@{exit_code=$taskExit;finished_at=(Get-Date).ToString('o');scope='Text-vector format only; unchanged DUT, part and clock; no board test'} | ConvertTo-Json | Set-Content -LiteralPath status.json -Encoding utf8
Get-Content -LiteralPath run.log -Tail 12
exit $taskExit
