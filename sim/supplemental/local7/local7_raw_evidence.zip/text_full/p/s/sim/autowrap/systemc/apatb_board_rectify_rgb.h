// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================

extern "C" void AESL_WRAP_board_rectify_rgb (
volatile void* src,
volatile void* dst,
volatile void* status,
volatile void* hint,
volatile void* corners,
int binary_enable,
int mode,
int threshold,
int bgr,
volatile void* geometry,
volatile void* diagnostics);
