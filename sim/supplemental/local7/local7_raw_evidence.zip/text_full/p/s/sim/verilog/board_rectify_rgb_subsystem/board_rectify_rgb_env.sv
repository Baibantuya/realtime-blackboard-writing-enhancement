//==============================================================
//Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
//Tool Version Limit: 2025.11
//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
//
//==============================================================
`ifndef BOARD_RECTIFY_RGB_ENV__SV                                                                                   
    `define BOARD_RECTIFY_RGB_ENV__SV                                                                               
                                                                                                                    
                                                                                                                    
    class board_rectify_rgb_env extends uvm_env;                                                                          
                                                                                                                    
        board_rectify_rgb_virtual_sequencer board_rectify_rgb_virtual_sqr;                                                      
        board_rectify_rgb_config board_rectify_rgb_cfg;                                                                         
                                                                                                                    
        axi_pkg::axi_env#(32,4,8,3,1) axi_master_gmem0;
        axi_pkg::axi_env#(32,4,8,3,1) axi_master_gmem1;
        axi_pkg::axi_env#(32,4,8,3,1) axi_master_gmem2;
        axi_pkg::axi_env#(7,4,4,3,1) axi_lite_control;
                                                                                                                    
        board_rectify_rgb_reference_model   refm;                                                                         
                                                                                                                    
        board_rectify_rgb_subsystem_monitor subsys_mon;                                                                   
                                                                                                                    
        `uvm_component_utils_begin(board_rectify_rgb_env)                                                                 
        `uvm_field_object (refm, UVM_DEFAULT | UVM_REFERENCE)                                                       
        `uvm_field_object (board_rectify_rgb_virtual_sqr, UVM_DEFAULT | UVM_REFERENCE)                                    
        `uvm_field_object (board_rectify_rgb_cfg        , UVM_DEFAULT)                                                    
        `uvm_component_utils_end                                                                                    
                                                                                                                    
        function new (string name = "board_rectify_rgb_env", uvm_component parent = null);                              
            super.new(name, parent);                                                                                
        endfunction                                                                                                 
                                                                                                                    
        extern virtual function void build_phase(uvm_phase phase);                                                  
        extern virtual function void connect_phase(uvm_phase phase);                                                
        extern virtual task          run_phase(uvm_phase phase);                                                    
                                                                                                                    
    endclass                                                                                                        
                                                                                                                    
    function void board_rectify_rgb_env::build_phase(uvm_phase phase);                                                    
        super.build_phase(phase);                                                                                   
        board_rectify_rgb_cfg = board_rectify_rgb_config::type_id::create("board_rectify_rgb_cfg", this);                           
                                                                                                                    

        board_rectify_rgb_cfg.gmem0_cfg.set_default();
        board_rectify_rgb_cfg.gmem0_cfg.drv_type = axi_pkg::SLAVE;
        board_rectify_rgb_cfg.gmem0_cfg.reset_level = axi_pkg::RESET_LEVEL_LOW;
        board_rectify_rgb_cfg.gmem0_cfg.write_latency_mode = TRANSACTION_FIRST;
        board_rectify_rgb_cfg.gmem0_cfg.read_latency_mode = TRANSACTION_FIRST;
        uvm_config_db#(axi_pkg::axi_cfg)::set(this, "axi_master_gmem0*", "cfg", board_rectify_rgb_cfg.gmem0_cfg);
        axi_master_gmem0 = axi_pkg::axi_env#(32,4,8,3,1)::type_id::create("axi_master_gmem0", this);

        board_rectify_rgb_cfg.gmem1_cfg.set_default();
        board_rectify_rgb_cfg.gmem1_cfg.drv_type = axi_pkg::SLAVE;
        board_rectify_rgb_cfg.gmem1_cfg.reset_level = axi_pkg::RESET_LEVEL_LOW;
        board_rectify_rgb_cfg.gmem1_cfg.write_latency_mode = TRANSACTION_FIRST;
        board_rectify_rgb_cfg.gmem1_cfg.read_latency_mode = TRANSACTION_FIRST;
        uvm_config_db#(axi_pkg::axi_cfg)::set(this, "axi_master_gmem1*", "cfg", board_rectify_rgb_cfg.gmem1_cfg);
        axi_master_gmem1 = axi_pkg::axi_env#(32,4,8,3,1)::type_id::create("axi_master_gmem1", this);

        board_rectify_rgb_cfg.gmem2_cfg.set_default();
        board_rectify_rgb_cfg.gmem2_cfg.drv_type = axi_pkg::SLAVE;
        board_rectify_rgb_cfg.gmem2_cfg.reset_level = axi_pkg::RESET_LEVEL_LOW;
        board_rectify_rgb_cfg.gmem2_cfg.write_latency_mode = TRANSACTION_FIRST;
        board_rectify_rgb_cfg.gmem2_cfg.read_latency_mode = TRANSACTION_FIRST;
        uvm_config_db#(axi_pkg::axi_cfg)::set(this, "axi_master_gmem2*", "cfg", board_rectify_rgb_cfg.gmem2_cfg);
        axi_master_gmem2 = axi_pkg::axi_env#(32,4,8,3,1)::type_id::create("axi_master_gmem2", this);

        board_rectify_rgb_cfg.control_cfg.set_default();
        board_rectify_rgb_cfg.control_cfg.drv_type = axi_pkg::MASTER;
        board_rectify_rgb_cfg.control_cfg.reset_level = axi_pkg::RESET_LEVEL_LOW;
        uvm_config_db#(axi_pkg::axi_cfg)::set(this, "axi_lite_control*", "cfg", board_rectify_rgb_cfg.control_cfg);
        axi_lite_control = axi_pkg::axi_env#(7,4,4,3,1)::type_id::create("axi_lite_control", this);



        refm = board_rectify_rgb_reference_model::type_id::create("refm", this);


        uvm_config_db#(board_rectify_rgb_reference_model)::set(this, "*", "refm", refm);


        `uvm_info(this.get_full_name(), "set reference model by uvm_config_db", UVM_LOW)


        subsys_mon = board_rectify_rgb_subsystem_monitor::type_id::create("subsys_mon", this);


        board_rectify_rgb_virtual_sqr = board_rectify_rgb_virtual_sequencer::type_id::create("board_rectify_rgb_virtual_sqr", this);
        `uvm_info(this.get_full_name(), "build_phase done", UVM_LOW)
    endfunction


    function void board_rectify_rgb_env::connect_phase(uvm_phase phase);
        super.connect_phase(phase);


        if(board_rectify_rgb_cfg.gmem0_cfg.drv_type==axi_pkg::MASTER ||board_rectify_rgb_cfg.gmem0_cfg.drv_type==axi_pkg::SLAVE)
            board_rectify_rgb_virtual_sqr.gmem0_sqr = axi_master_gmem0.vsqr;
        axi_master_gmem0.item_wtr_port.connect(subsys_mon.gmem0_wtr_imp);
        axi_master_gmem0.item_rtr_port.connect(subsys_mon.gmem0_rtr_imp);
        uvm_callbacks#(axi_pkg::axi_state, axi_pkg::axi_state_cbs)::add(axi_master_gmem0.state, refm.axi_memaccess_cb_gmem0);
        if(board_rectify_rgb_cfg.gmem1_cfg.drv_type==axi_pkg::MASTER ||board_rectify_rgb_cfg.gmem1_cfg.drv_type==axi_pkg::SLAVE)
            board_rectify_rgb_virtual_sqr.gmem1_sqr = axi_master_gmem1.vsqr;
        axi_master_gmem1.item_wtr_port.connect(subsys_mon.gmem1_wtr_imp);
        axi_master_gmem1.item_rtr_port.connect(subsys_mon.gmem1_rtr_imp);
        uvm_callbacks#(axi_pkg::axi_state, axi_pkg::axi_state_cbs)::add(axi_master_gmem1.state, refm.axi_memaccess_cb_gmem1);
        if(board_rectify_rgb_cfg.gmem2_cfg.drv_type==axi_pkg::MASTER ||board_rectify_rgb_cfg.gmem2_cfg.drv_type==axi_pkg::SLAVE)
            board_rectify_rgb_virtual_sqr.gmem2_sqr = axi_master_gmem2.vsqr;
        axi_master_gmem2.item_wtr_port.connect(subsys_mon.gmem2_wtr_imp);
        axi_master_gmem2.item_rtr_port.connect(subsys_mon.gmem2_rtr_imp);
        uvm_callbacks#(axi_pkg::axi_state, axi_pkg::axi_state_cbs)::add(axi_master_gmem2.state, refm.axi_memaccess_cb_gmem2);
        if(board_rectify_rgb_cfg.control_cfg.drv_type==axi_pkg::MASTER ||board_rectify_rgb_cfg.control_cfg.drv_type==axi_pkg::SLAVE)
            board_rectify_rgb_virtual_sqr.control_sqr = axi_lite_control.vsqr;
        axi_lite_control.item_wtr_port.connect(subsys_mon.control_wtr_imp);
        axi_lite_control.item_rtr_port.connect(subsys_mon.control_rtr_imp);
        refm.board_rectify_rgb_cfg = board_rectify_rgb_cfg;
        `uvm_info(this.get_full_name(), "connect phase done", UVM_LOW)
    endfunction


    task board_rectify_rgb_env::run_phase(uvm_phase phase);
        `uvm_info(this.get_full_name(), "board_rectify_rgb_env is running", UVM_LOW)
    endtask


`endif
