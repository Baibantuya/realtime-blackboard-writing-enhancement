// ==============================================================
// Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2025.2 (64-bit)
// Tool Version Limit: 2025.11
// Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
// Copyright 2022-2025 Advanced Micro Devices, Inc. All Rights Reserved.
// 
// ==============================================================
#ifndef XBOARD_RECTIFY_RGB_H
#define XBOARD_RECTIFY_RGB_H

#ifdef __cplusplus
extern "C" {
#endif

/***************************** Include Files *********************************/
#ifndef __linux__
#include "xil_types.h"
#include "xil_assert.h"
#include "xstatus.h"
#include "xil_io.h"
#else
#include <stdint.h>
#include <assert.h>
#include <dirent.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>
#include <stddef.h>
#endif
#include "xboard_rectify_rgb_hw.h"

/**************************** Type Definitions ******************************/
#ifdef __linux__
typedef uint8_t u8;
typedef uint16_t u16;
typedef uint32_t u32;
typedef uint64_t u64;
#else
typedef struct {
#ifdef SDT
    char *Name;
#else
    u16 DeviceId;
#endif
    u32 Control_BaseAddress;
} XBoard_rectify_rgb_Config;
#endif

typedef struct {
    u32 Control_BaseAddress;
    u32 IsReady;
} XBoard_rectify_rgb;

typedef u32 word_type;

/***************** Macros (Inline Functions) Definitions *********************/
#ifndef __linux__
#define XBoard_rectify_rgb_WriteReg(BaseAddress, RegOffset, Data) \
    Xil_Out32((BaseAddress) + (RegOffset), (u32)(Data))
#define XBoard_rectify_rgb_ReadReg(BaseAddress, RegOffset) \
    Xil_In32((BaseAddress) + (RegOffset))
#else
#define XBoard_rectify_rgb_WriteReg(BaseAddress, RegOffset, Data) \
    *(volatile u32*)((BaseAddress) + (RegOffset)) = (u32)(Data)
#define XBoard_rectify_rgb_ReadReg(BaseAddress, RegOffset) \
    *(volatile u32*)((BaseAddress) + (RegOffset))

#define Xil_AssertVoid(expr)    assert(expr)
#define Xil_AssertNonvoid(expr) assert(expr)

#define XST_SUCCESS             0
#define XST_DEVICE_NOT_FOUND    2
#define XST_OPEN_DEVICE_FAILED  3
#define XIL_COMPONENT_IS_READY  1
#endif

/************************** Function Prototypes *****************************/
#ifndef __linux__
#ifdef SDT
int XBoard_rectify_rgb_Initialize(XBoard_rectify_rgb *InstancePtr, UINTPTR BaseAddress);
XBoard_rectify_rgb_Config* XBoard_rectify_rgb_LookupConfig(UINTPTR BaseAddress);
#else
int XBoard_rectify_rgb_Initialize(XBoard_rectify_rgb *InstancePtr, u16 DeviceId);
XBoard_rectify_rgb_Config* XBoard_rectify_rgb_LookupConfig(u16 DeviceId);
#endif
int XBoard_rectify_rgb_CfgInitialize(XBoard_rectify_rgb *InstancePtr, XBoard_rectify_rgb_Config *ConfigPtr);
#else
int XBoard_rectify_rgb_Initialize(XBoard_rectify_rgb *InstancePtr, const char* InstanceName);
int XBoard_rectify_rgb_Release(XBoard_rectify_rgb *InstancePtr);
#endif

void XBoard_rectify_rgb_Start(XBoard_rectify_rgb *InstancePtr);
u32 XBoard_rectify_rgb_IsDone(XBoard_rectify_rgb *InstancePtr);
u32 XBoard_rectify_rgb_IsIdle(XBoard_rectify_rgb *InstancePtr);
u32 XBoard_rectify_rgb_IsReady(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_EnableAutoRestart(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_DisableAutoRestart(XBoard_rectify_rgb *InstancePtr);

void XBoard_rectify_rgb_Set_src(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_src(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_Set_dst(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_dst(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_Set_status(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_status(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_Set_hint(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_hint(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_Set_corners(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_corners(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_Set_binary_enable(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_binary_enable(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_Set_mode(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_mode(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_Set_threshold(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_threshold(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_Set_bgr(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_bgr(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_Set_geometry(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_geometry(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_Set_diagnostics(XBoard_rectify_rgb *InstancePtr, u32 Data);
u32 XBoard_rectify_rgb_Get_diagnostics(XBoard_rectify_rgb *InstancePtr);

void XBoard_rectify_rgb_InterruptGlobalEnable(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_InterruptGlobalDisable(XBoard_rectify_rgb *InstancePtr);
void XBoard_rectify_rgb_InterruptEnable(XBoard_rectify_rgb *InstancePtr, u32 Mask);
void XBoard_rectify_rgb_InterruptDisable(XBoard_rectify_rgb *InstancePtr, u32 Mask);
void XBoard_rectify_rgb_InterruptClear(XBoard_rectify_rgb *InstancePtr, u32 Mask);
u32 XBoard_rectify_rgb_InterruptGetEnabled(XBoard_rectify_rgb *InstancePtr);
u32 XBoard_rectify_rgb_InterruptGetStatus(XBoard_rectify_rgb *InstancePtr);

#ifdef __cplusplus
}
#endif

#endif
