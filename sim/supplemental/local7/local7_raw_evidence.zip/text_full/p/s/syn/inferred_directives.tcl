# Inferred from syn.compile.pipeline_loops=64
set_directive_pipeline pack/VITIS_LOOP_98_1
set_directive_pipeline board_rectify_rgb/VITIS_LOOP_152_1
set_directive_pipeline board_rectify_rgb/VITIS_LOOP_159_2
set_directive_pipeline board_rectify_rgb/VITIS_LOOP_161_3
# Inferred from performance & pipeline pragmas/directives
set_directive_loop_flatten coordinates/VITIS_LOOP_20_1
